package model;

import threads.Monitor;
import threads.Student;

public class Main {
	
	
	public static void main(String[] args) {
		// Numero de sillas que hay
		int chairs=3;
		// office del monitor
		Office office= new Office(chairs);
		// Numeros al azar del numero de estudiantes que hay
		int numStudents= (int)((Math.random()*10)+ 1);

		for (int i = 0; i < numStudents; i++) {
			Student nuevo= new Student(i, office);
			Thread threadStudent = new Thread(nuevo);
			threadStudent.start();
		}
		
		//Inicializamos el monitor
		int idMonitor=0;
		Monitor monitor= new Monitor(idMonitor,office);
		Thread hiloMonitor = new Thread(monitor);
		hiloMonitor.start();
	}

}
