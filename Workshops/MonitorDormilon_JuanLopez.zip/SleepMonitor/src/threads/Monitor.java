package threads;

import model.Office;

public class Monitor implements Runnable {
	/**
	 * Indica si el monitor se encuentra dormido
	 */
	private boolean sleep;
	/**
	 * Identificador del monitor que se encuentra actualmente
	 */
	private int id;
	/**
	 * Indica la oficina a la que esta asignada el monitor
	 */
	private Office office;
	/**
	 * Metodo constructor del monitor, se indica el id que tendr�, y empieza su artributo sleep como True
	 * @param id el identificador del monitor  
	 */
	public Monitor(int id,Office office) {
		this.id = id;
		this.sleep = true;
		this.office= office;
	}
	
	/**
	 * Metodo run del hilo
	 */
	@Override
	public void run() {
		int consultTime;
		int attendStudent;
		while (true) {
			try {
				if (office.isPendingStudent()) {
					if(sleep==true) {
						sleep= false;
					}
					consultTime = (int) (Math.random() * 90 + 10);
					attendStudent = office.attendStudent();
					System.out.println("El monitor se ha despertado para atender el estudiante "+attendStudent);
					Thread.sleep(consultTime);
					System.out.println("El monitor ha atendido al siguiente estudiante en cola con id " + attendStudent + " en un tiempo de "+ consultTime);
				}
				else {
					System.out.println("El monitor se encuentra dormido!");
					Thread.sleep(20);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public boolean isSleep() {
		return sleep;
	}
	
	public void setSleep(boolean sleep) {
		this.sleep = sleep;
	}
	
	public int getId() {
		return id;
	}
	
	public void setId(int id) {
		this.id = id;
	}

}
